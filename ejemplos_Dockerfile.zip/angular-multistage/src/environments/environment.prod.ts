export const environment = {
  production: true,
  appApi: {
    baseUrl: 'https://contacts-api.vatsaev.com'
  },
  socketConfig: {
    url: 'https://contacts-api.vatsaev.com',
    opts: {
      transports: ['websocket']
    }
  }
};
