export enum ContactsEventTypes {
  // SERVER SIDE SOCKET ACTIONS
  LIVE_CREATED = '[Contacts] LIVE CREATED',
  LIVE_UPDATED = '[Contacts] LIVE UPDATED',
  LIVE_DELETED = '[Contacts] LIVE DELETED',
}
